﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString =
            @"Server=.;Database=Medicines;User Id=sa;Password=Inofefa860702##;Trust Server Certificate=true;";
    }
}
