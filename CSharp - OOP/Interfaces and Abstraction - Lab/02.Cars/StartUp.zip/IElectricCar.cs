﻿namespace Cars
{
    public interface IElectricCar : ICar
    {
        int Battery { get; }
    }
}
