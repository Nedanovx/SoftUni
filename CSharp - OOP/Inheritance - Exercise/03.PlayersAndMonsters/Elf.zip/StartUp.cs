﻿namespace PlayersAndMonsters;

public class StartUp
{
    static void Main(string[] args)
    {
        BladeKnight bladeKnight = new BladeKnight("Dancho", 7);
        Console.WriteLine(bladeKnight);
    }
}