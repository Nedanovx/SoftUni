﻿namespace MilitaryElite.Models.Enum
{
    public enum State
    {
        inProgress,
        Finished
    }
}
