﻿namespace MilitaryElite.Models.Enum
{
    public enum Corps 
    {
        Airforces,
        Marines 
    }
}
