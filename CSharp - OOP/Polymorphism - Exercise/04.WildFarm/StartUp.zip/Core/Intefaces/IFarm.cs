﻿namespace WildFarm.Core.Intefaces
{
    public interface IFarm
    {
        void Lives();
    }
}
