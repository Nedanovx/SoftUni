﻿namespace WildFarm.Models.Interfaces
{
    public interface IMammal
    {
        string LivingRegion { get; }
    }
}
