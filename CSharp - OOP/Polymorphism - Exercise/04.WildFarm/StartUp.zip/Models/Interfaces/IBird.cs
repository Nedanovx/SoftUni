﻿namespace WildFarm.Models.Interfaces
{
    public interface IBird
    {
        double WingSize { get; }
    }
}
