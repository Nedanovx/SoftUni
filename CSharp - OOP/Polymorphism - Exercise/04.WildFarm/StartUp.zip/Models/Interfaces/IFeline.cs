﻿namespace WildFarm.Models.Interfaces
{
    public interface IFeline
    {
        string Breed { get; }
    }
}
