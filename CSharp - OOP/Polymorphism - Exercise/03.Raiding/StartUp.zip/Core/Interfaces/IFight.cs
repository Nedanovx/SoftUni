﻿namespace Raiding.Core.Interfaces
{
    public interface IFight
    {
        void Start();
    }
}
